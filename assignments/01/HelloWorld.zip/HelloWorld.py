n = input()
names = list()

for i in range(int(n)):
    name = input()
    names.append(name)

for name in names:
    print(f"Hello, {name}!")
